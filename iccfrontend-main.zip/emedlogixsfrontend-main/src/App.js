
import { Header } from "./components/Header";
import './App.css'
import Codedet from "./components/Codedet";
import { Main } from "./components/Main";


function App() {
  return (

    <>
    <div className="page">
    <Header/>
    
   
    </div>   
  </>
 
  );
}

export default App;
