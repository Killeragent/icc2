import { Typography } from "@mui/material";
import React from "react";
import "../styles/Table2.css";
export const Table2 = () => {
  return (
    <div className="tableTop">
     
        <div className="Tablecontent">
          <p>Hcc:</p>
          <p>Back reference:</p>
          <p>Alert:</p>
          <p>Clinical defination:</p>
          <p>Code history:</p>
        </div>
     
    </div>
  );
};